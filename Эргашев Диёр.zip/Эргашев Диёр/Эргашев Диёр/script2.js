

function admin(){
    document.getElementById("admin").innerText= `Admin: ${document.getElementById('name').value}`//интерполяция
    // "Admin: " + document.getElementById("name").value;
    }